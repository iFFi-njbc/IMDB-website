package MyPack;
import java.io.*;

public class Moviesinfo implements java.io.Serializable {

	/* Properties */
	private String MovieName = null;
	private double Rating = 0.0;
        private double Year = 0.0;
	private String Genre = null;

	/* Empty Constructor */
	public Moviesinfo()
 	{
		MovieName = ""; 
		Rating = 0.0; 
		Year = 0.0;
		Genre = ""; 
	}

	public Moviesinfo(String n, double r, double y, String g)
	{
		MovieName = n;
		Rating = r;
		Year = y;
		Genre = g;
	}

	/* Getter and Setter Methods */
	public String getMovieName() {
		return MovieName;
	}

	public void setMovieName(String m) {
		MovieName = m;
	}

	public double getRating() {
		return Rating;
	}

	public void setRating(double r) {
		Rating = r;
	}
       
        public double getYear() {
		return Year;
	}

	public void setYear(double y) {
		Year = y;
	}
	public String getGenre() {
		return Genre;
	}

	public void setGenre(String g) {
		Genre = g;
	}
}