package MyPack;

import MyPack.Moviesinfo;
import java.sql.*;
import java.io.*;
import java.util.*;

public class MoviesDAO
{

	   	String driver = "com.mysql.jdbc.Driver";
    		    String connection = "jdbc:mysql://localhost/imdb";
    		    String user = "root";                 
    		    String password = "root";        


    			Connection con = null;
    			Statement state = null;
    			ResultSet result;
		ArrayList <Moviesinfo> movies = new ArrayList <Moviesinfo> ();
		ArrayList <Moviesinfo> TOPmovies = new ArrayList <Moviesinfo> ();

	public MoviesDAO()
	{
 
      			 try{
            			Class.forName(driver);
            			con = DriverManager.getConnection(connection, user, password);
            			System.out.println("Successfully connected to database.");
           		    }
        		catch(SQLException e){
            					System.out.println("Couldn't connect to database.");
            				     }
        		catch(Exception e){
            					System.out.println("Couldn't load driver.");
            				     }

    	}



        public String addmovie(String name, double r, double year, String genre)
	{
		int value = 0;	
		try
		{
      	    		state = con.createStatement();
	    		result = state.executeQuery("select * from movies where MovieName='"+name+"' AND Rating='"+r+"' AND Year='"+year+"' AND Genre='"+genre+"'");
	    		if(!result.isBeforeFirst())
	    		{
	   			Statement state1 = con.createStatement();
            			value = state1.executeUpdate("insert into movies(MovieName, Rating, Year, Genre)"+
                                 				 "values('"+name+"', "+r+", "+year+", '"+genre+"')");
				con.close();
	        	}
	   		else
	    		{
				con.close();
				return "MOVIE already exists";
 	    		}
		}
         catch(SQLException e)
	    {
		System.out.println("Query error");
            } 

			if(value != 0)
			{
				return "Movie added Successfully";	
			
			}
	    		else
	    		{
				return "Movie not added due to some error";
 	    		} 
			
	}

	
	public String deletemovie(String name, double r, double year, String genre)
	{
		int value1 = 0;
	try
	{
      	    state = con.createStatement();
	    result = state.executeQuery("SELECT * from movies where MovieName='"+name+"' AND Rating='"+r+"' AND Year='"+year+"' AND Genre='"+genre+"'");
	    if(!result.isBeforeFirst())
	    {
		con.close();
		return "Movie doesn't exist";
		
	    }
	    else
	    {

	   	Statement state1 = con.createStatement();
            	value1 = state1.executeUpdate("delete from movies where MovieName='"+name+"' AND Rating='"+r+"' AND Year='"+year+"' AND Genre='"+genre+"'");
		con.close();
 	    }
	}
         catch(SQLException e)
	    {
		System.out.println("Query error.");
            } 

			if(value1 != 0)
			{
				return "Movie DELETED Successfully";	
			
			}
	    		else
	    		{
				return "Movie not DELETED due to some error";
 	    		} 


	}


	public String updatemovie(String name, Moviesinfo movie)
	{
		int value2 = 0;
	try
	{
			
      	    state = con.createStatement();
	    result = state.executeQuery("SELECT * from movies where MovieName='"+movie.getMovieName()+"' AND Rating='"+movie.getRating()+"' AND Year='"+movie.getYear()+"' AND Genre='"+movie.getGenre()+"'");
	    if(!result.isBeforeFirst())
	    {
		      	Statement state1 = con.createStatement();
			//String query = "UPDATE records set UserName = '" + newUN + "' , Email = '" + newE + "' , Password = '" + newP + "' WHERE UserName = '"+key1+"' AND Password = '"+key2+"'";
	    		value2 = state1.executeUpdate("UPDATE movies set MovieName = '" + movie.getMovieName() + "' , Rating = '" + movie.getRating() + "' , Year = '" + movie.getYear() + "', Genre = '" + movie.getGenre() + "' WHERE MovieName = '"+name+"'");
			con.close();
	    }
	    else
	    {
			con.close();
			return "Such Movie already exists";
	    }
	}
         catch(SQLException e)
	    {
		System.out.println("Query error.");
            } 

			if(value2 != 0)
			{

				return "Movie Updated Successfully";	
			
			}
	    		else
	    		{

				return "Movie not Updated due to some error";
 	    		} 



	}


        public Moviesinfo showmovie(String name)
	{
		Moviesinfo movie = null;
		        try{
            
            			state = con.createStatement();
           			result = state.executeQuery("select * from movies where MovieName='"+name+"'");
			        if(!result.isBeforeFirst())
	    			{
					con.close();
				}
				else
				{
					 result.beforeFirst();
				         while(result.next())
             				 {
               					 String N = result.getString("MovieName");
               					 double R = result.getDouble("Rating");
						 double Y = result.getDouble("Year");
						 String G = result.getString("Genre");
               					      
						 movie = new Moviesinfo(N, R, Y, G);
						con.close();
			                 }
				}
				

            		}
        		catch(SQLException e){
            		System.out.println("Query error.");
            		}
           		   return movie;

			
	}

        public int genre(String[] genres)
	{
	     int exist=0;
	  try
	  {
		String dummy1;
		String dummy2 = "%";
		for(int j=0; j<genres.length; j++)
			{
					dummy1 = genres[j];
				        state = con.createStatement();
	    				result = state.executeQuery("select distinct * from movies where Genre LIKE '"+dummy2+"' '"+dummy1+"' '"+dummy2+"'");
	    			if(result.next())
	    			{  
					exist = 1;
					result.beforeFirst();
          				while(result.next())
              				{
                				String moviename = result.getString("MovieName");
                				double rating = result.getDouble("Rating");
                				double year = result.getDouble("Year");
						String genre = result.getString("Genre");
						Moviesinfo movie = new Moviesinfo(moviename, rating, year, genre);
						movies.add(movie);
					}
				}


			}
		con.close();
	}
        catch(SQLException e)
	{
		System.out.println("Query error.");
	}
		return exist;

	}
	

	public Moviesinfo[] showgenremovies()
	{
		Moviesinfo[] movie = new Moviesinfo[movies.size()];
 			for(int i=0; i<movies.size(); i++)
   			{
       				movie[i] = (Moviesinfo)movies.get(i);
   			}

		return movie;
	}

	public int top5movies()
	{
		//Moviesinfo[] movies = new Moviesinfo[5];
		int exist=0;
		        try{

            			state = con.createStatement();
           			result = state.executeQuery("SELECT * FROM movies ORDER BY Rating DESC LIMIT 5");
			        if(!result.isBeforeFirst())
	    			{
					exist = 0;
					con.close();
				}
				else
				{
					exist = 1;
					 result.beforeFirst();
				         while(result.next())
             				 {
               					 String N = result.getString("MovieName");
               					 double R = result.getDouble("Rating");
						 double Y = result.getDouble("Year");
						 String G = result.getString("Genre");
						
						Moviesinfo movie = new Moviesinfo(N, R, Y, G);
						TOPmovies.add(movie);
			                 }
				}
				
				
			     con.close();
            		}
        		catch(SQLException e){
            		System.out.println("Query error.");
            		}
           		   return exist;
	
	} 
	public Moviesinfo[] showtop5movies()
	{
		Moviesinfo[] TOPmovie = new Moviesinfo[TOPmovies.size()];
 			for(int i=0; i<TOPmovies.size(); i++)
   			{
       				TOPmovie[i] = (Moviesinfo)TOPmovies.get(i);
   			}

		return TOPmovie;
	}
}