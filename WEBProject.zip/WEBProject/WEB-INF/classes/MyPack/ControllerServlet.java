package MyPack;

import java.io.*;
import java.sql.*;
import java.util.*; 
import javax.servlet.*;
import javax.servlet.http.*; 
public class ControllerServlet extends HttpServlet { 


// This method only calls processRequest() 

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws 
ServletException, IOException { 
processRequest(request, response); 
} 

// This method only calls processRequest() 
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws 
ServletException, IOException { 
processRequest(request, response); 
} 

protected void processRequest(HttpServletRequest request, 
HttpServletResponse response) throws ServletException, IOException {

// retrieving value of action parameter 
//String userAction = request.getParameter("action"); 


// if request comes to move to addperson.jsp from hyperlink 
//if (userAction.equals("addperson") )  
response.sendRedirect("Login.jsp"); 
}
}



 