package MyPack;
import java.io.*;

public class Personinfo implements java.io.Serializable {

	/* Properties */
	private String UserName = null;
	private String Email = null;
        private String Password = null;

	/* Empty Constructor */
	public Personinfo()
 	{
		UserName = ""; 
		Email = ""; 
		Password = ""; 
	}

	public Personinfo(String n, String e, String p)
	{
		UserName = n;
		Email = e;
		Password = p;
	}

	/* Getter and Setter Methods */
	public String getUserName() {
		return UserName;
	}

	public void setUserName(String s) {
		UserName = s;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String i) {
		Email = i;
	}
       
        public String getPassword() {
		return Password;
	}

	public void setPassword(String e) {
		Password = e;
	}
}