package MyPack;

import MyPack.Personinfo;
import java.sql.*;
import java.io.*;
import java.util.*;

public class PersonDAO
{

	   	String driver = "com.mysql.jdbc.Driver";
    		    String connection = "jdbc:mysql://localhost/assignment";
    		    String user = "root";                 
    		    String password = "root";        


    			Connection con = null;
    			Statement state = null;
    			ResultSet result;

	public PersonDAO()
	{
 
      			 try{
            			Class.forName(driver);
            			con = DriverManager.getConnection(connection, user, password);
            			System.out.println("Successfully connected to database.");
           		    }
        		catch(SQLException e){
            					System.out.println("Couldn't connect to database.");
            				     }
        		catch(Exception e){
            					System.out.println("Couldn't load driver.");
            				     }

    	}



        public String addperson(String name, String email, String pass)
	{
		int value = 0;	
		try
		{
      	    		state = con.createStatement();
	    		result = state.executeQuery("select * from records where UserName='"+name+"' AND Password='"+pass+"'");
	    		if(!result.isBeforeFirst())
	    		{
	   			Statement state1 = con.createStatement();
            			value = state1.executeUpdate("insert into records(UserName, Email, Password)"+
                                 				 "values('"+name+"', '"+email+"', '"+pass+"')");
				con.close();
	        	}
	   		else
	    		{
				con.close();
				return "USERNAME and Password already exists";
 	    		}
		}
         catch(SQLException e)
	    {
		System.out.println("Query error");
            } 

			if(value != 0)
			{
				return "Record added Successfully";	
			
			}
	    		else
	    		{
				return "Record not added due to some error";
 	    		} 
			
	}

	
	public String deletePerson(String name, String pass)
	{
		int value1 = 0;
	try
	{
      	    state = con.createStatement();
	    result = state.executeQuery("SELECT * from records where UserName='"+name+"' AND Password='"+pass+"'");
	    if(!result.isBeforeFirst())
	    {
		con.close();
		return "USERNAME and Password doesn't exist";
		
	    }
	    else
	    {

	   	Statement state1 = con.createStatement();
            	value1 = state1.executeUpdate("delete from records where UserName='"+name+"' AND Password='"+pass+"'");
		con.close();
 	    }
	}
         catch(SQLException e)
	    {
		System.out.println("Query error.");
            } 

			if(value1 != 0)
			{
				return "Record DELETED Successfully";	
			
			}
	    		else
	    		{
				return "Record not DELETED due to some error";
 	    		} 


	}


	public String UpdatePerson(String name, String pass, Personinfo person)
	{
		int value2 = 0;
	try
	{
			
      	    state = con.createStatement();
	    result = state.executeQuery("SELECT * from records where UserName='"+person.getUserName()+"' AND Password='"+person.getPassword()+"'");
	    if(!result.isBeforeFirst())
	    {
		      	Statement state1 = con.createStatement();
			//String query = "UPDATE records set UserName = '" + newUN + "' , Email = '" + newE + "' , Password = '" + newP + "' WHERE UserName = '"+key1+"' AND Password = '"+key2+"'";
	    		value2 = state1.executeUpdate("UPDATE records set UserName = '" + person.getUserName() + "' , Email = '" + person.getEmail() + "' , Password = '" + person.getPassword() + "' WHERE UserName = '"+name+"' AND Password = '"+pass+"'");
			con.close();
	    }
	    else
	    {
			con.close();
			return "Such username and password already exists";
	    }
	}
         catch(SQLException e)
	    {
		System.out.println("Query error.");
            } 

			if(value2 != 0)
			{

				return "Record Updated Successfully";	
			
			}
	    		else
	    		{

				return "Record not Updated due to some error";
 	    		} 



	}


        public Personinfo showperson(String name, String pass)
	{
		Personinfo person = null;
		        try{
            
            			state = con.createStatement();
           			result = state.executeQuery("select * from records where UserName='"+name+"' and Password='"+pass+"'");
			        if(!result.isBeforeFirst())
	    			{
					con.close();
				}
				else
				{
					 result.beforeFirst();
				         while(result.next())
             				 {
               					 String N = result.getString("UserName");
               					 String E = result.getString("Email");
						 String P = result.getString("Password");
               					      
						 person = new Personinfo(N, E, P);
						con.close();
			                 }
				}
				

            		}
        		catch(SQLException e){
            		System.out.println("Query error.");
            		}
           		   return person;

			
	}


        public Personinfo loginperson(String email, String pass)
	{
		Personinfo person = null;
		        try{
            
            			state = con.createStatement();
           			result = state.executeQuery("select * from records where Email='"+email+"' and Password='"+pass+"'");
			        if(!result.isBeforeFirst())
	    			{
					con.close();
				}
				else
				{
					 result.beforeFirst();
				         while(result.next())
             				 {
               					 String N = result.getString("UserName");
               					 String E = result.getString("Email");
						 String P = result.getString("Password");
               					      
						 person = new Personinfo(N, E, P);
						con.close();
			                 }
				}
				

            		}
        		catch(SQLException e){
            		System.out.println("Query error.");
            		}
           		   return person;

			
	}


	

}